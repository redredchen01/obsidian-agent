# HR Bot v1.0 — Telegram HR Admin Bot System

**Status**: 🚀 MVP Development in Progress
**Version**: v1.0.0 (upgrade from v0.5)
**Release Date**: 2026-03-31

## Overview

HR Bot is a comprehensive Telegram-based HR administration system featuring:
- Multi-workspace support (up to 4 separate Telegram bots)
- Employee management (hiring, performance, leave)
- Payroll integration
- MCP Server for AI agents
- Docker containerization
- PostgreSQL backend

## Upgrade from v0.5 → v1.0

### v0.5 Features (Complete)
✅ Basic Telegram bot setup
✅ Employee profile CRUD
✅ Leave request system
✅ Basic reporting

### v1.0 New Features (In Development)
- [ ] **MCP Server Integration** — Enable Claude agents to manage HR data
- [ ] **PostgreSQL Backend** — Replace file-based storage with database
- [ ] **Advanced Payroll** — Salary calculations, tax integration
- [ ] **Performance Reviews** — Structured evaluation system
- [ ] **Attendance Tracking** — Real-time clock in/out
- [ ] **Document Management** — Contract and certificate storage
- [ ] **Notifications** — Proactive alerts and reminders
- [ ] **Analytics Dashboard** — HR metrics and KPIs
- [ ] **Multi-workspace** — Support multiple companies
- [ ] **REST API** — Programmatic access

## Quick Start

```bash
# Clone and setup
git clone <repo>
cd HR-Bot-v1
pip install -r requirements.txt

# Configure
cp .env.example .env
# Edit .env with your settings

# Run
python hr_bot.py
```

## Project Structure

```
HR-Bot-v1/
├── src/
│   ├── bot.py              # Main Telegram bot
│   ├── mcp_server.py       # MCP integration
│   ├── database.py         # PostgreSQL models
│   ├── payroll.py          # Payroll logic
│   └── handlers/           # Telegram message handlers
├── tests/
│   ├── test_bot.py
│   ├── test_database.py
│   └── test_payroll.py
├── docker/
│   ├── Dockerfile
│   └── docker-compose.yml
├── docs/
│   ├── ARCHITECTURE.md
│   ├── MCP_SERVER.md
│   └── DEPLOYMENT.md
├── requirements.txt
├── .env.example
└── README.md
```

## Development Roadmap

### Phase 1: Foundation (Sprint 1)
- [x] Project structure
- [ ] PostgreSQL setup
- [ ] Telegram bot framework
- [ ] Basic employee CRUD

### Phase 2: Core Features (Sprint 2)
- [ ] Leave management
- [ ] Payroll basic
- [ ] MCP server skeleton
- [ ] Tests

### Phase 3: Advanced (Sprint 3)
- [ ] Performance reviews
- [ ] Attendance tracking
- [ ] Document management
- [ ] Dashboard

### Phase 4: Production (Sprint 4)
- [ ] Docker deployment
- [ ] CI/CD pipeline
- [ ] Documentation
- [ ] v1.0.0 release

## Testing

```bash
pytest tests/ -v --cov=src/
```

## Deployment

```bash
# Using Docker
docker-compose up -d

# Manual setup
python -m src.bot
```

## Contributing

See [DEVELOPMENT.md](docs/DEVELOPMENT.md) for guidelines.

## License

MIT

---

**Migration from v0.5**:
All v0.5 data can be imported via the migration script:
```bash
python scripts/migrate_from_v0.5.py --input-dir /path/to/v0.5
```

*Last Updated: 2026-03-31*
