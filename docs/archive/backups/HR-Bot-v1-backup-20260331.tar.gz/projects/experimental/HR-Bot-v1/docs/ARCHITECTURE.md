# HR Bot v1.0 — Architecture

## Overview

HR Bot is a comprehensive Telegram-based HR administration system with:
- Multi-workspace support (up to 4 separate Telegram bots)
- Employee management (hiring, performance, leave)
- Payroll integration with tax calculations
- MCP Server for AI agent integration
- PostgreSQL backend
- Docker containerization

## System Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Telegram Users                        │
└──────────────┬──────────────────────────────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│         Telegram Bot Handler (bot.py)                     │
│  - Command routing (/start, /help, /profile, etc.)       │
│  - Message processing                                     │
│  - Error handling & logging                               │
└──────────────┬──────────────────────────────────────────┘
               │
    ┌──────────┼──────────┐
    │          │          │
    ▼          ▼          ▼
┌──────────┬──────────┬──────────┐
│ Database │ MCP      │ External │
│ Ops      │ Server   │ Services │
│(db.py)   │(mcp.py)  │          │
└──────────┴──────────┴──────────┘
    │          │          │
    └──────────┼──────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────┐
│         PostgreSQL Database                               │
│  - Employees, LeaveRequests, Payroll, Attendance         │
│  - PerformanceReviews, Documents, AuditLogs              │
└──────────────────────────────────────────────────────────┘
```

## Core Modules

### 1. **bot.py** — Telegram Bot Handler
- Command handlers: `/start`, `/help`, `/status`, `/profile`, `/leave`, `/payroll`, `/attendance`, `/admin`, `/review`, `/reports`, `/backup`
- Message handler for text input
- Error handling and logging
- Main entry point with `application.run_polling()`

### 2. **database.py** — SQLAlchemy Models
Models for:
- **Employee**: User profiles with contact info, department, salary
- **LeaveRequest**: Leave applications with approval workflow
- **AttendanceRecord**: Daily check-in/check-out tracking
- **PayrollRecord**: Monthly salary processing and history
- **PerformanceReview**: Performance evaluations
- **Document**: Contract and certificate storage
- **AuditLog**: Audit trail for compliance

### 3. **payroll.py** — Payroll Processing
- **PayrollCalculator**: Tax calculations, social security deductions
- **PayrollProcessor**: Monthly payroll batch processing
- Supports:
  - Progressive tax brackets
  - National/health/labor insurance
  - Allowances and bonuses
  - Deductions tracking

### 4. **mcp_server.py** — MCP Integration
Enables Claude agents to:
- Query employee data
- Manage leave requests
- Access payroll information
- Track attendance
- Generate reports

## Data Flow

### Employee Leave Request Flow
```
User → /leave command
    ↓
Profile lookup in Employee table
    ↓
Create LeaveRequest (PENDING status)
    ↓
Admin → /review command
    ↓
Approve/Reject decision
    ↓
Update LeaveRequest.status
    ↓
Audit log entry
```

### Payroll Processing Flow
```
Scheduled task → process_monthly_payroll()
    ↓
Load all active employees
    ↓
PayrollCalculator.calculate_net_salary() for each
    ↓
Create PayrollRecord entries
    ↓
Admin approval workflow
    ↓
Mark as PAID
    ↓
Generate statements
```

## Database Schema

### Core Tables

#### employees
- id (PK)
- user_id (UNIQUE, Telegram user ID)
- name, email, phone
- department, position, employment_type
- hire_date, base_salary
- is_active, created_at, updated_at

#### leave_requests
- id (PK)
- employee_id (FK)
- leave_type (ENUM: annual, sick, unpaid, special, maternity, paternity)
- start_date, end_date, reason
- status (ENUM: pending, approved, rejected, cancelled)
- approved_by, approved_at
- created_at, updated_at

#### attendance_records
- id (PK)
- employee_id (FK)
- date (UNIQUE with employee_id)
- check_in_time, check_out_time
- status (present, absent, late, early_leave)
- notes, created_at, updated_at

#### payroll_records
- id (PK)
- employee_id (FK)
- month (UNIQUE with employee_id)
- base_salary, allowances, deductions, bonus
- tax, net_salary
- status (ENUM: draft, processed, paid, cancelled)
- processed_by, processed_at
- created_at, updated_at

## Key Features

### 1. Multi-Workspace Support
- Support for up to 4 separate Telegram bots
- Each workspace has independent employee/payroll data
- Shared MCP server for agent access

### 2. Security
- Telegram user ID as primary identity
- Admin role verification for sensitive operations
- Audit logging for all changes
- Environment variable configuration for secrets

### 3. Scalability
- PostgreSQL for horizontal scaling
- Connection pooling
- Indexed queries for performance
- Batch processing for payroll

### 4. Integration
- MCP Server for Claude agent access
- REST API (future phase)
- Document storage support
- Export capabilities (CSV, PDF)

## Configuration

Environment variables in `.env`:
```
TELEGRAM_TOKEN=<token>
ADMIN_IDS=<comma-separated user IDs>
DATABASE_URL=postgresql://...
MCP_SERVER_HOST=0.0.0.0
MCP_SERVER_PORT=3000
```

## Deployment

### Docker
```bash
docker-compose up -d
```

### Manual
```bash
pip install -r requirements.txt
python -m src.bot
```

### Database Setup
```bash
alembic upgrade head
```

## Development Roadmap

### Phase 1: Foundation ✅
- Project structure
- PostgreSQL setup
- Telegram bot framework
- Basic employee CRUD

### Phase 2: Core Features (In Progress)
- Leave management
- Payroll basic
- MCP server skeleton
- Tests

### Phase 3: Advanced
- Performance reviews
- Attendance tracking
- Document management
- Dashboard

### Phase 4: Production
- Docker deployment
- CI/CD pipeline
- Documentation
- v1.0.0 release

## Testing

```bash
pytest tests/ -v --cov=src/
```

## See Also
- [MCP_SERVER.md](MCP_SERVER.md) — Detailed MCP integration guide
- [DEPLOYMENT.md](DEPLOYMENT.md) — Deployment instructions
