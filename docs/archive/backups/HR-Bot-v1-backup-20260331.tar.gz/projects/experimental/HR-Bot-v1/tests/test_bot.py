"""Tests for HR Bot main module"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from telegram import Update, User, Message
from telegram.ext import ContextTypes


class TestBotCommands:
    """Test bot command handlers"""

    @pytest.mark.asyncio
    async def test_start_command(self):
        """Test /start command"""
        # Create mock update and context
        mock_user = User(id=123, is_bot=False, first_name="Test")
        mock_message = AsyncMock(spec=Message)
        mock_message.reply_text = AsyncMock()

        mock_update = MagicMock(spec=Update)
        mock_update.effective_user = mock_user
        mock_update.message = mock_message

        mock_context = MagicMock(spec=ContextTypes.DEFAULT_TYPE)

        # Import and test
        from src.bot import start

        await start(mock_update, mock_context)

        # Verify reply was sent
        mock_message.reply_text.assert_called_once()
        call_args = mock_message.reply_text.call_args
        assert "HR Bot v1.0" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_help_command(self):
        """Test /help command"""
        mock_message = AsyncMock(spec=Message)
        mock_message.reply_text = AsyncMock()

        mock_update = MagicMock(spec=Update)
        mock_update.message = mock_message

        mock_context = MagicMock(spec=ContextTypes.DEFAULT_TYPE)

        from src.bot import help_command

        await help_command(mock_update, mock_context)

        mock_message.reply_text.assert_called_once()
        call_args = mock_message.reply_text.call_args
        assert "命令列表" in call_args[0][0]

    @pytest.mark.asyncio
    async def test_admin_command_no_permission(self):
        """Test /admin command without admin privileges"""
        mock_user = User(id=999, is_bot=False, first_name="Regular")
        mock_message = AsyncMock(spec=Message)
        mock_message.reply_text = AsyncMock()

        mock_update = MagicMock(spec=Update)
        mock_update.effective_user = mock_user
        mock_update.message = mock_message

        mock_context = MagicMock(spec=ContextTypes.DEFAULT_TYPE)

        from src.bot import admin_command

        await admin_command(mock_update, mock_context)

        mock_message.reply_text.assert_called_once()
        call_args = mock_message.reply_text.call_args
        assert "沒有管理員權限" in call_args[0][0]


class TestPayrollCalculator:
    """Test payroll calculations"""

    def test_calculate_net_salary(self):
        """Test salary calculation"""
        from src.payroll import PayrollCalculator

        calculator = PayrollCalculator(base_salary=100000)
        result = calculator.calculate_net_salary(
            base_salary=100000,
            allowances=5000,
            deductions=2000,
            bonus=10000,
        )

        assert result["gross_salary"] == 115000
        assert result["net_salary"] > 0
        assert result["total_deductions"] > 0
        assert "income_tax" in result
        assert "national_insurance" in result

    def test_progressive_tax_calculation(self):
        """Test progressive tax rates"""
        from src.payroll import PayrollCalculator

        calculator = PayrollCalculator(base_salary=50000)
        result = calculator.calculate_net_salary(base_salary=50000)

        assert result["income_tax"] > 0
        assert result["net_salary"] < result["gross_salary"]


class TestDatabaseModels:
    """Test database models"""

    def test_employee_creation(self):
        """Test creating an employee record"""
        from datetime import date
        from src.database import Employee

        employee = Employee(
            user_id=123,
            name="John Doe",
            email="john@example.com",
            department="Engineering",
            position="Software Engineer",
            employment_type="Full-time",
            hire_date=date(2024, 1, 1),
            base_salary=100000,
        )

        assert employee.name == "John Doe"
        assert employee.department == "Engineering"
        assert employee.is_active is True

    def test_employee_repr(self):
        """Test employee string representation"""
        from datetime import date
        from src.database import Employee

        employee = Employee(
            user_id=123,
            name="Jane Smith",
            email="jane@example.com",
            department="HR",
            position="HR Manager",
            employment_type="Full-time",
            hire_date=date(2024, 1, 1),
            base_salary=80000,
        )

        assert "Jane Smith" in repr(employee)
        assert "HR Manager" in repr(employee)
