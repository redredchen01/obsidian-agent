"""
HR Bot v1.0 — Payroll Module
Salary calculations, tax integration, and payroll processing
"""

from datetime import datetime, date
from typing import Optional, Dict
from decimal import Decimal
import logging

from sqlalchemy.orm import Session
from .database import PayrollRecord, Employee, PayrollStatus

logger = logging.getLogger(__name__)


class PayrollCalculator:
    """Handle salary calculations and tax integration"""

    # Tax rates and thresholds (Taiwan 2026 example)
    TAX_BRACKETS = [
        (1_000_000, 0.05),
        (2_000_000, 0.10),
        (5_000_000, 0.20),
        (float('inf'), 0.30),
    ]

    NATIONAL_INSURANCE_RATE = 0.0865  # 8.65%
    HEALTH_INSURANCE_RATE = 0.0330  # 3.30%
    LABOR_INSURANCE_RATE = 0.0100  # 1.00%

    def __init__(self, base_salary: float):
        self.base_salary = base_salary

    def calculate_income_tax(self, annual_income: float) -> float:
        """Calculate progressive income tax"""
        tax = 0.0
        previous_threshold = 0

        for threshold, rate in self.TAX_BRACKETS:
            if annual_income <= previous_threshold:
                break

            taxable_amount = min(annual_income, threshold) - previous_threshold
            tax += taxable_amount * rate
            previous_threshold = threshold

        return tax / 12  # Monthly tax

    def calculate_social_security(self, gross_salary: float) -> Dict[str, float]:
        """Calculate social security deductions"""
        return {
            "national_insurance": gross_salary * self.NATIONAL_INSURANCE_RATE,
            "health_insurance": gross_salary * self.HEALTH_INSURANCE_RATE,
            "labor_insurance": gross_salary * self.LABOR_INSURANCE_RATE,
        }

    def calculate_net_salary(
        self,
        base_salary: float,
        allowances: float = 0,
        deductions: float = 0,
        bonus: float = 0,
    ) -> Dict[str, float]:
        """Calculate net salary with all deductions"""
        gross_salary = base_salary + allowances + bonus

        # Social security
        social_security = self.calculate_social_security(gross_salary)
        total_ss_deduction = sum(social_security.values())

        # Income tax (simplified annual calculation)
        annual_income = gross_salary * 12
        monthly_tax = self.calculate_income_tax(annual_income)

        # Total deductions
        total_deductions = deductions + total_ss_deduction + monthly_tax

        # Net salary
        net_salary = gross_salary - total_deductions

        return {
            "gross_salary": gross_salary,
            "allowances": allowances,
            "bonus": bonus,
            "deductions": deductions,
            "national_insurance": social_security["national_insurance"],
            "health_insurance": social_security["health_insurance"],
            "labor_insurance": social_security["labor_insurance"],
            "income_tax": monthly_tax,
            "total_deductions": total_deductions,
            "net_salary": max(0, net_salary),
        }


class PayrollProcessor:
    """Process monthly payroll for employees"""

    def __init__(self, db_session: Session):
        self.db = db_session
        self.logger = logger

    def process_monthly_payroll(
        self,
        month: date,
        allowances_map: Optional[Dict[int, float]] = None,
        bonus_map: Optional[Dict[int, float]] = None,
        deductions_map: Optional[Dict[int, float]] = None,
    ) -> list[PayrollRecord]:
        """Process payroll for all active employees for a given month"""
        self.logger.info(f"Processing payroll for {month.strftime('%Y-%m')}")

        # Get all active employees
        employees = self.db.query(Employee).filter(Employee.is_active == True).all()
        payroll_records = []

        allowances_map = allowances_map or {}
        bonus_map = bonus_map or {}
        deductions_map = deductions_map or {}

        for employee in employees:
            # Check if record already exists
            existing = self.db.query(PayrollRecord).filter(
                PayrollRecord.employee_id == employee.id,
                PayrollRecord.month == month,
            ).first()

            if existing:
                self.logger.warning(
                    f"Payroll record already exists for {employee.name} in {month}"
                )
                continue

            # Calculate salary
            calculator = PayrollCalculator(employee.base_salary)
            salary_breakdown = calculator.calculate_net_salary(
                base_salary=employee.base_salary,
                allowances=allowances_map.get(employee.id, 0),
                bonus=bonus_map.get(employee.id, 0),
                deductions=deductions_map.get(employee.id, 0),
            )

            # Create payroll record
            record = PayrollRecord(
                employee_id=employee.id,
                month=month,
                base_salary=employee.base_salary,
                allowances=salary_breakdown.get("allowances", 0),
                deductions=salary_breakdown.get("deductions", 0),
                bonus=salary_breakdown.get("bonus", 0),
                tax=salary_breakdown.get("income_tax", 0),
                net_salary=salary_breakdown.get("net_salary", 0),
                status=PayrollStatus.DRAFT,
            )

            self.db.add(record)
            payroll_records.append(record)
            self.logger.info(
                f"Created payroll for {employee.name}: "
                f"Net ₹{salary_breakdown['net_salary']:,.2f}"
            )

        self.db.commit()
        self.logger.info(f"Processed payroll for {len(payroll_records)} employees")
        return payroll_records

    def approve_payroll(
        self,
        payroll_id: int,
        approved_by: int,
    ) -> Optional[PayrollRecord]:
        """Approve a payroll record"""
        record = self.db.query(PayrollRecord).filter(
            PayrollRecord.id == payroll_id
        ).first()

        if not record:
            self.logger.error(f"Payroll record {payroll_id} not found")
            return None

        record.status = PayrollStatus.PROCESSED
        record.processed_by = approved_by
        record.processed_at = datetime.utcnow()
        self.db.commit()

        self.logger.info(f"Approved payroll {payroll_id}")
        return record

    def mark_as_paid(self, payroll_id: int) -> Optional[PayrollRecord]:
        """Mark payroll as paid"""
        record = self.db.query(PayrollRecord).filter(
            PayrollRecord.id == payroll_id
        ).first()

        if not record:
            self.logger.error(f"Payroll record {payroll_id} not found")
            return None

        if record.status != PayrollStatus.PROCESSED:
            self.logger.warning(
                f"Cannot mark unprocessed payroll as paid: {payroll_id}"
            )
            return None

        record.status = PayrollStatus.PAID
        self.db.commit()

        self.logger.info(f"Marked payroll {payroll_id} as paid")
        return record

    def get_payroll_summary(
        self,
        month: date,
    ) -> Dict[str, any]:
        """Get payroll summary for a month"""
        records = self.db.query(PayrollRecord).filter(
            PayrollRecord.month == month
        ).all()

        total_gross = sum(r.base_salary + r.allowances + r.bonus for r in records)
        total_deductions = sum(r.deductions + r.tax for r in records)
        total_net = sum(r.net_salary for r in records)

        return {
            "month": month.strftime("%Y-%m"),
            "total_employees": len(records),
            "total_gross": total_gross,
            "total_deductions": total_deductions,
            "total_net": total_net,
            "processed": sum(1 for r in records if r.status == PayrollStatus.PROCESSED),
            "paid": sum(1 for r in records if r.status == PayrollStatus.PAID),
        }
