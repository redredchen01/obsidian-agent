"""
HR Bot v1.0 — Database Models
PostgreSQL schema for employee, leave, payroll, and attendance management
"""

from datetime import datetime
from typing import Optional, List

from sqlalchemy import (
    Column, Integer, String, Text, Float, DateTime,
    Date, Boolean, ForeignKey, Enum, UniqueConstraint
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
import enum

Base = declarative_base()


class Employee(Base):
    """Employee profile"""
    __tablename__ = "employees"

    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, unique=True, nullable=False)  # Telegram user ID
    name = Column(String(100), nullable=False)
    email = Column(String(100), unique=True, nullable=False)
    phone = Column(String(20), nullable=True)
    department = Column(String(100), nullable=False)
    position = Column(String(100), nullable=False)
    employment_type = Column(String(50), nullable=False)  # Full-time, Part-time, Contract
    hire_date = Column(Date, nullable=False)
    base_salary = Column(Float, nullable=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    leave_requests = relationship("LeaveRequest", back_populates="employee", cascade="all, delete-orphan")
    payroll_records = relationship("PayrollRecord", back_populates="employee", cascade="all, delete-orphan")
    attendance_records = relationship("AttendanceRecord", back_populates="employee", cascade="all, delete-orphan")
    performance_reviews = relationship("PerformanceReview", back_populates="employee", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<Employee {self.name} ({self.position})>"


class LeaveType(str, enum.Enum):
    """Types of leave"""
    ANNUAL = "annual"
    SICK = "sick"
    UNPAID = "unpaid"
    SPECIAL = "special"
    MATERNITY = "maternity"
    PATERNITY = "paternity"


class LeaveStatus(str, enum.Enum):
    """Leave request status"""
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"


class LeaveRequest(Base):
    """Employee leave request"""
    __tablename__ = "leave_requests"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    leave_type = Column(Enum(LeaveType), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    reason = Column(Text, nullable=True)
    status = Column(Enum(LeaveStatus), default=LeaveStatus.PENDING)
    approved_by = Column(Integer, nullable=True)  # Employee ID of approver
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employee = relationship("Employee", back_populates="leave_requests")

    def __repr__(self) -> str:
        return f"<LeaveRequest {self.employee_id} {self.leave_type.value}>"


class AttendanceRecord(Base):
    """Daily attendance record"""
    __tablename__ = "attendance_records"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    check_in_time = Column(DateTime, nullable=True)
    check_out_time = Column(DateTime, nullable=True)
    date = Column(Date, nullable=False)
    status = Column(String(50), default="present")  # present, absent, late, early_leave
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (UniqueConstraint("employee_id", "date", name="uq_employee_date"),)

    # Relationships
    employee = relationship("Employee", back_populates="attendance_records")

    def __repr__(self) -> str:
        return f"<AttendanceRecord {self.employee_id} {self.date}>"


class PayrollStatus(str, enum.Enum):
    """Payroll record status"""
    DRAFT = "draft"
    PROCESSED = "processed"
    PAID = "paid"
    CANCELLED = "cancelled"


class PayrollRecord(Base):
    """Monthly payroll record"""
    __tablename__ = "payroll_records"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    month = Column(Date, nullable=False)  # First day of the month
    base_salary = Column(Float, nullable=False)
    allowances = Column(Float, default=0)
    deductions = Column(Float, default=0)
    bonus = Column(Float, default=0)
    tax = Column(Float, default=0)
    net_salary = Column(Float, nullable=False)
    status = Column(Enum(PayrollStatus), default=PayrollStatus.DRAFT)
    processed_by = Column(Integer, nullable=True)  # Employee ID of processor
    processed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (UniqueConstraint("employee_id", "month", name="uq_employee_month"),)

    # Relationships
    employee = relationship("Employee", back_populates="payroll_records")

    def __repr__(self) -> str:
        return f"<PayrollRecord {self.employee_id} {self.month}>"


class PerformanceReview(Base):
    """Employee performance review"""
    __tablename__ = "performance_reviews"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    review_date = Column(Date, nullable=False)
    rating = Column(Integer, nullable=False)  # 1-5 scale
    reviewer_name = Column(String(100), nullable=False)
    comments = Column(Text, nullable=True)
    goals = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    employee = relationship("Employee", back_populates="performance_reviews")

    def __repr__(self) -> str:
        return f"<PerformanceReview {self.employee_id} {self.review_date}>"


class Document(Base):
    """Store employee documents (contracts, certificates, etc.)"""
    __tablename__ = "documents"

    id = Column(Integer, primary_key=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False)
    document_type = Column(String(100), nullable=False)  # contract, certificate, etc.
    file_path = Column(String(255), nullable=False)
    file_name = Column(String(255), nullable=False)
    file_size = Column(Integer, nullable=True)
    uploaded_by = Column(Integer, nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<Document {self.employee_id} {self.document_type}>"


class AuditLog(Base):
    """Audit trail for all changes"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True)
    action = Column(String(100), nullable=False)  # CREATE, UPDATE, DELETE
    table_name = Column(String(100), nullable=False)
    record_id = Column(Integer, nullable=False)
    user_id = Column(Integer, nullable=False)  # Who made the change
    old_values = Column(Text, nullable=True)  # JSON
    new_values = Column(Text, nullable=True)  # JSON
    timestamp = Column(DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<AuditLog {self.action} {self.table_name}:{self.record_id}>"
