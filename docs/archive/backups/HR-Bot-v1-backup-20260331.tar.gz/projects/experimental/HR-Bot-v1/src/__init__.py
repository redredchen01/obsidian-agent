"""HR Bot v1.0 - Telegram HR Administration System"""

__version__ = "1.0.0"
__author__ = "HR Bot Team"
__description__ = "Comprehensive Telegram-based HR administration system"

from .bot import main, start, help_command
from .database import (
    Base,
    Employee,
    LeaveRequest,
    AttendanceRecord,
    PayrollRecord,
    PerformanceReview,
    Document,
    AuditLog,
)
from .payroll import PayrollCalculator, PayrollProcessor
from .mcp_server import HRMCPServer

__all__ = [
    "main",
    "start",
    "help_command",
    "Base",
    "Employee",
    "LeaveRequest",
    "AttendanceRecord",
    "PayrollRecord",
    "PerformanceReview",
    "Document",
    "AuditLog",
    "PayrollCalculator",
    "PayrollProcessor",
    "HRMCPServer",
]
