"""
HR Bot v1.0 — MCP Server Integration
Enables Claude agents and external tools to interact with HR data
"""

import logging
from typing import Optional, Dict, Any, List
from datetime import date

logger = logging.getLogger(__name__)


class HRMCPServer:
    """MCP (Model Context Protocol) Server for HR Bot

    Provides tools for:
    - Employee data queries
    - Leave request management
    - Payroll access
    - Attendance tracking
    - Report generation
    """

    def __init__(self, database_session: Optional[Any] = None):
        """Initialize MCP Server

        Args:
            database_session: SQLAlchemy session for database access
        """
        self.db = database_session
        self.logger = logger

    # Employee Management Tools

    def get_employee(self, employee_id: int) -> Optional[Dict[str, Any]]:
        """Get employee details"""
        if not self.db:
            return None

        from .database import Employee

        employee = self.db.query(Employee).filter(
            Employee.id == employee_id
        ).first()

        if not employee:
            return None

        return {
            "id": employee.id,
            "user_id": employee.user_id,
            "name": employee.name,
            "email": employee.email,
            "phone": employee.phone,
            "department": employee.department,
            "position": employee.position,
            "employment_type": employee.employment_type,
            "hire_date": employee.hire_date.isoformat(),
            "base_salary": float(employee.base_salary),
            "is_active": employee.is_active,
        }

    def list_employees(
        self,
        department: Optional[str] = None,
        is_active: bool = True,
    ) -> List[Dict[str, Any]]:
        """List employees with optional filtering"""
        if not self.db:
            return []

        from .database import Employee

        query = self.db.query(Employee)

        if department:
            query = query.filter(Employee.department == department)

        if is_active is not None:
            query = query.filter(Employee.is_active == is_active)

        employees = query.all()

        return [
            {
                "id": e.id,
                "name": e.name,
                "position": e.position,
                "department": e.department,
                "email": e.email,
            }
            for e in employees
        ]

    def create_employee(
        self,
        user_id: int,
        name: str,
        email: str,
        department: str,
        position: str,
        employment_type: str,
        hire_date: date,
        base_salary: float,
    ) -> Dict[str, Any]:
        """Create new employee record"""
        if not self.db:
            return {"error": "Database not configured"}

        from .database import Employee

        employee = Employee(
            user_id=user_id,
            name=name,
            email=email,
            department=department,
            position=position,
            employment_type=employment_type,
            hire_date=hire_date,
            base_salary=base_salary,
        )

        self.db.add(employee)
        self.db.commit()

        self.logger.info(f"Created employee: {name}")

        return {
            "id": employee.id,
            "name": employee.name,
            "email": employee.email,
            "status": "created",
        }

    # Leave Management Tools

    def get_leave_requests(
        self,
        employee_id: Optional[int] = None,
        status: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """Get leave requests with optional filtering"""
        if not self.db:
            return []

        from .database import LeaveRequest

        query = self.db.query(LeaveRequest)

        if employee_id:
            query = query.filter(LeaveRequest.employee_id == employee_id)

        if status:
            query = query.filter(LeaveRequest.status == status)

        requests = query.all()

        return [
            {
                "id": r.id,
                "employee_id": r.employee_id,
                "leave_type": r.leave_type.value,
                "start_date": r.start_date.isoformat(),
                "end_date": r.end_date.isoformat(),
                "status": r.status.value,
                "reason": r.reason,
            }
            for r in requests
        ]

    def approve_leave_request(
        self,
        request_id: int,
        approved_by: int,
    ) -> Dict[str, Any]:
        """Approve a leave request"""
        if not self.db:
            return {"error": "Database not configured"}

        from .database import LeaveRequest, LeaveStatus
        from datetime import datetime

        request = self.db.query(LeaveRequest).filter(
            LeaveRequest.id == request_id
        ).first()

        if not request:
            return {"error": f"Leave request {request_id} not found"}

        request.status = LeaveStatus.APPROVED
        request.approved_by = approved_by
        request.approved_at = datetime.utcnow()
        self.db.commit()

        self.logger.info(f"Approved leave request {request_id}")

        return {
            "id": request.id,
            "status": "approved",
        }

    # Payroll Tools

    def get_payroll(
        self,
        employee_id: int,
        month: date,
    ) -> Optional[Dict[str, Any]]:
        """Get payroll record for an employee"""
        if not self.db:
            return None

        from .database import PayrollRecord

        record = self.db.query(PayrollRecord).filter(
            PayrollRecord.employee_id == employee_id,
            PayrollRecord.month == month,
        ).first()

        if not record:
            return None

        return {
            "id": record.id,
            "employee_id": record.employee_id,
            "month": record.month.isoformat(),
            "base_salary": float(record.base_salary),
            "allowances": float(record.allowances),
            "deductions": float(record.deductions),
            "bonus": float(record.bonus),
            "tax": float(record.tax),
            "net_salary": float(record.net_salary),
            "status": record.status.value,
        }

    # Attendance Tools

    def get_attendance(
        self,
        employee_id: int,
        start_date: date,
        end_date: date,
    ) -> List[Dict[str, Any]]:
        """Get attendance records for a date range"""
        if not self.db:
            return []

        from .database import AttendanceRecord

        records = self.db.query(AttendanceRecord).filter(
            AttendanceRecord.employee_id == employee_id,
            AttendanceRecord.date >= start_date,
            AttendanceRecord.date <= end_date,
        ).all()

        return [
            {
                "date": r.date.isoformat(),
                "check_in": r.check_in_time.isoformat() if r.check_in_time else None,
                "check_out": r.check_out_time.isoformat() if r.check_out_time else None,
                "status": r.status,
            }
            for r in records
        ]

    # Report Generation Tools

    def generate_report(
        self,
        report_type: str,
        start_date: date,
        end_date: date,
        filters: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Generate HR reports"""
        filters = filters or {}

        if report_type == "attendance":
            return self._generate_attendance_report(start_date, end_date, filters)
        elif report_type == "payroll":
            return self._generate_payroll_report(start_date, end_date, filters)
        elif report_type == "leave":
            return self._generate_leave_report(start_date, end_date, filters)
        else:
            return {"error": f"Unknown report type: {report_type}"}

    def _generate_attendance_report(
        self,
        start_date: date,
        end_date: date,
        filters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Generate attendance report"""
        if not self.db:
            return {"error": "Database not configured"}

        from .database import AttendanceRecord

        query = self.db.query(AttendanceRecord).filter(
            AttendanceRecord.date >= start_date,
            AttendanceRecord.date <= end_date,
        )

        records = query.all()

        return {
            "report_type": "attendance",
            "period": f"{start_date.isoformat()} to {end_date.isoformat()}",
            "total_records": len(records),
            "present": sum(1 for r in records if r.status == "present"),
            "absent": sum(1 for r in records if r.status == "absent"),
            "late": sum(1 for r in records if r.status == "late"),
        }

    def _generate_payroll_report(
        self,
        start_date: date,
        end_date: date,
        filters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Generate payroll report"""
        if not self.db:
            return {"error": "Database not configured"}

        from .database import PayrollRecord

        query = self.db.query(PayrollRecord).filter(
            PayrollRecord.month >= start_date,
            PayrollRecord.month <= end_date,
        )

        records = query.all()

        total_gross = sum(r.base_salary + r.allowances + r.bonus for r in records)
        total_net = sum(r.net_salary for r in records)

        return {
            "report_type": "payroll",
            "period": f"{start_date.isoformat()} to {end_date.isoformat()}",
            "total_records": len(records),
            "total_gross": float(total_gross),
            "total_net": float(total_net),
        }

    def _generate_leave_report(
        self,
        start_date: date,
        end_date: date,
        filters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Generate leave report"""
        if not self.db:
            return {"error": "Database not configured"}

        from .database import LeaveRequest

        query = self.db.query(LeaveRequest).filter(
            LeaveRequest.start_date >= start_date,
            LeaveRequest.start_date <= end_date,
        )

        requests = query.all()

        return {
            "report_type": "leave",
            "period": f"{start_date.isoformat()} to {end_date.isoformat()}",
            "total_requests": len(requests),
            "approved": sum(1 for r in requests if r.status.value == "approved"),
            "pending": sum(1 for r in requests if r.status.value == "pending"),
            "rejected": sum(1 for r in requests if r.status.value == "rejected"),
        }
