"""
HR Bot v1.0 — Message and Callback Handlers
Modular handlers for different HR operations
"""

__all__ = []
