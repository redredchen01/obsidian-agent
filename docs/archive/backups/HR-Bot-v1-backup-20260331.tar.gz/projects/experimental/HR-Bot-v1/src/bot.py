"""
HR Bot v1.0 — Main Telegram Bot Handler
Provides HR administration interface via Telegram
"""

import logging
import os
from datetime import datetime
from typing import Optional

from dotenv import load_dotenv
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    filters, ContextTypes, ConversationHandler
)

# Load environment
load_dotenv()
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
ADMIN_IDS = [int(id) for id in os.getenv("ADMIN_IDS", "").split(",") if id.strip()]

# Logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# States for ConversationHandler
PROFILE_VIEW, PROFILE_EDIT = range(2)
LEAVE_REQUEST, LEAVE_APPROVE = range(2)
PAYROLL_VIEW, PAYROLL_EXPORT = range(2)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /start command"""
    user = update.effective_user
    keyboard = [
        [InlineKeyboardButton("👤 個人檔案", callback_data="profile")],
        [InlineKeyboardButton("📋 請假管理", callback_data="leave")],
        [InlineKeyboardButton("💰 薪資查詢", callback_data="payroll")],
        [InlineKeyboardButton("⚙️ 管理員", callback_data="admin")],
        [InlineKeyboardButton("ℹ️ 幫助", callback_data="help")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        f"👋 歡迎使用 HR Bot v1.0\n\n"
        f"您好 {user.first_name}！\n\n"
        f"請選擇一個功能：",
        reply_markup=reply_markup
    )


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /help command"""
    help_text = """
🤖 *HR Bot v1.0 命令列表*

*一般命令：*
/start - 顯示主選單
/help - 顯示此幫助
/status - 檢查服務狀態

*功能命令：*
/profile - 查看/編輯個人檔案
/leave - 提交或查看請假申請
/payroll - 查詢薪資資訊
/attendance - 簽到/簽退

*管理員命令：*
/admin - 進入管理員模式
/review - 審批待處理項目
/reports - 生成 HR 報告
/backup - 備份系統資料

*提示：*
• 直接輸入文字可以快速搜尋員工
• 使用按鈕進行互動操作
• 所有資料變更都會被記錄

如需支援，請聯繫 HR 部門
"""
    await update.message.reply_text(help_text, parse_mode="Markdown")


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /status command"""
    status_text = """
✅ *HR Bot v1.0 狀態*

🟢 主服務：正常
🟢 資料庫：連接中
🟢 MCP 伺服器：就緒
🟢 文件存儲：可用

版本：1.0.0
最後更新：2026-03-31
    """
    await update.message.reply_text(status_text, parse_mode="Markdown")


async def profile_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /profile command - View/edit employee profile"""
    user_id = update.effective_user.id
    keyboard = [
        [InlineKeyboardButton("📖 查看檔案", callback_data="profile_view")],
        [InlineKeyboardButton("✏️ 編輯檔案", callback_data="profile_edit")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "👤 *個人檔案*\n\n"
        "選擇操作：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def leave_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /leave command - Manage leave requests"""
    keyboard = [
        [InlineKeyboardButton("📝 提交請假申請", callback_data="leave_request")],
        [InlineKeyboardButton("📋 查看申請歷史", callback_data="leave_history")],
        [InlineKeyboardButton("📊 剩餘假期", callback_data="leave_balance")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "📋 *請假管理*\n\n"
        "選擇操作：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def payroll_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /payroll command - Query salary information"""
    keyboard = [
        [InlineKeyboardButton("💵 本月薪資", callback_data="payroll_current")],
        [InlineKeyboardButton("📈 薪資歷史", callback_data="payroll_history")],
        [InlineKeyboardButton("🧾 扣稅單據", callback_data="payroll_documents")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "💰 *薪資查詢*\n\n"
        "選擇操作：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def attendance_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /attendance command - Clock in/out"""
    user_id = update.effective_user.id
    current_time = datetime.now().strftime("%H:%M")

    keyboard = [
        [InlineKeyboardButton("✋ 簽到", callback_data="checkin")],
        [InlineKeyboardButton("👋 簽退", callback_data="checkout")],
        [InlineKeyboardButton("📊 今日記錄", callback_data="attendance_today")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        f"⏰ *考勤簽卡*\n\n"
        f"當前時間：{current_time}\n\n"
        f"選擇操作：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /admin command - Admin mode (restricted)"""
    user_id = update.effective_user.id

    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ 您沒有管理員權限")
        return

    keyboard = [
        [InlineKeyboardButton("👥 員工管理", callback_data="admin_users")],
        [InlineKeyboardButton("✅ 審批申請", callback_data="admin_approvals")],
        [InlineKeyboardButton("📊 生成報告", callback_data="admin_reports")],
        [InlineKeyboardButton("⚙️ 系統設定", callback_data="admin_settings")],
        [InlineKeyboardButton("💾 備份資料", callback_data="admin_backup")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "⚙️ *管理員模式*\n\n"
        "選擇操作：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def review_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /review command - Review pending items"""
    user_id = update.effective_user.id

    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ 您沒有管理員權限")
        return

    await update.message.reply_text(
        "📋 *待審批項目*\n\n"
        "• 3 個請假申請\n"
        "• 2 個費用報銷\n"
        "• 1 個加班申請\n\n"
        "（此功能建構中）"
    )


async def reports_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /reports command - Generate HR reports"""
    user_id = update.effective_user.id

    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ 您沒有管理員權限")
        return

    keyboard = [
        [InlineKeyboardButton("👥 員工列表", callback_data="report_employees")],
        [InlineKeyboardButton("📊 考勤報告", callback_data="report_attendance")],
        [InlineKeyboardButton("💰 薪資統計", callback_data="report_payroll")],
        [InlineKeyboardButton("🏖️ 假期統計", callback_data="report_leave")],
        [InlineKeyboardButton("↩️ 返回", callback_data="back_to_main")],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    await update.message.reply_text(
        "📊 *HR 報告*\n\n"
        "選擇報告類型：",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )


async def backup_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /backup command - Backup system data"""
    user_id = update.effective_user.id

    if user_id not in ADMIN_IDS:
        await update.message.reply_text("❌ 您沒有管理員權限")
        return

    await update.message.reply_text(
        "💾 *系統備份*\n\n"
        "⏳ 正在準備備份...\n\n"
        "• 資料庫\n"
        "• 文件存儲\n"
        "• 配置檔案\n\n"
        "（此功能建構中）"
    )


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle regular text messages"""
    text = update.message.text

    if not text:
        return

    # Simple search by employee name/ID
    if len(text) >= 2:
        await update.message.reply_text(
            f"🔍 搜尋：{text}\n\n"
            f"（搜尋功能建構中）"
        )
    else:
        await update.message.reply_text(
            "請輸入至少 2 個字符進行搜尋"
        )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log the error and send a telegram message to notify the developer"""
    logger.error(msg="Exception while handling an update:", exc_info=context.error)

    if isinstance(update, Update) and update.effective_message:
        await update.effective_message.reply_text(
            "❌ 發生錯誤\n\n"
            "請稍後重試或聯繫管理員"
        )


def main() -> None:
    """Start the bot"""
    if not TELEGRAM_TOKEN:
        logger.error("TELEGRAM_TOKEN not set in environment variables")
        return

    # Create the Application
    application = Application.builder().token(TELEGRAM_TOKEN).build()

    # Add command handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CommandHandler("profile", profile_command))
    application.add_handler(CommandHandler("leave", leave_command))
    application.add_handler(CommandHandler("payroll", payroll_command))
    application.add_handler(CommandHandler("attendance", attendance_command))
    application.add_handler(CommandHandler("admin", admin_command))
    application.add_handler(CommandHandler("review", review_command))
    application.add_handler(CommandHandler("reports", reports_command))
    application.add_handler(CommandHandler("backup", backup_command))

    # Add message handler
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message)
    )

    # Add error handler
    application.add_error_handler(error_handler)

    # Start the Bot
    logger.info("🚀 HR Bot v1.0 Starting...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
